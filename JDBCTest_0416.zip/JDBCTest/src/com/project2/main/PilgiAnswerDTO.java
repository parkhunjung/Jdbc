package com.project2.main;

public class PilgiAnswerDTO {
	private String seq;
	private String answer;
	private String pilgiexamseq;
	private String learningseq;
	private String courseSubjectSeq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getPilgiexamseq() {
		return pilgiexamseq;
	}

	public void setPilgiexamseq(String pilgiexamseq) {
		this.pilgiexamseq = pilgiexamseq;
	}

	public String getLearningseq() {
		return learningseq;
	}

	public void setLearningseq(String learningseq) {
		this.learningseq = learningseq;
	}

	public String getCourseSubjectSeq() {
		return courseSubjectSeq;
	}

	public void setCourseSubjectSeq(String courseSubjectSeq) {
		this.courseSubjectSeq = courseSubjectSeq;
	}

}