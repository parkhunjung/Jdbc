package com.project2.main;

public class AttendedSudangDTO {

	private String seq;
	private String sudang;
	private String learningseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getSudang() {
		return sudang;
	}

	public void setSudang(String sudang) {
		this.sudang = sudang;
	}

	public String getLearningseq() {
		return learningseq;
	}

	public void setLearningseq(String learningseq) {
		this.learningseq = learningseq;
	}

}
