package com.project2.main;

public class RoomStatusDTO {

	private String seq;
	private String reservedate;
	private String roomseq;
	private String studyseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getReservedate() {
		return reservedate;
	}

	public void setReservedate(String reservedate) {
		this.reservedate = reservedate;
	}

	public String getRoomseq() {
		return roomseq;
	}

	public void setRoomseq(String roomseq) {
		this.roomseq = roomseq;
	}

	public String getStudyseq() {
		return studyseq;
	}

	public void setStudyseq(String studyseq) {
		this.studyseq = studyseq;
	}

}