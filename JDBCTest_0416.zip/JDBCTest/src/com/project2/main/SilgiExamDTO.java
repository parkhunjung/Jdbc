package com.project2.main;

public class SilgiExamDTO {
	private String seq;
	private String question;
	private String answer;
	private String coursesubjectseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getCoursesubjectseq() {
		return coursesubjectseq;
	}

	public void setCoursesubjectseq(String coursesubjectseq) {
		this.coursesubjectseq = coursesubjectseq;
	}

}
