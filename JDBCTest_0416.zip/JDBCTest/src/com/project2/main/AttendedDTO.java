package com.project2.main;

public class AttendedDTO {
	private String seq;
	private String intime;
	private String outtime;
	private String status;
	private String learningseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getIntime() {
		return intime;
	}

	public void setIntime(String intime) {
		this.intime = intime;
	}

	public String getOuttime() {
		return outtime;
	}

	public void setOuttime(String outtime) {
		this.outtime = outtime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLearningseq() {
		return learningseq;
	}

	public void setLearningseq(String learningseq) {
		this.learningseq = learningseq;
	}

}
