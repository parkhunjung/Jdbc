package com.project2.main;

public class TeacherSubjectDTO {

	private String seq;
	private String teacherseq;
	private String subjectseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getTeacherseq() {
		return teacherseq;
	}

	public void setTeacherseq(String teacherseq) {
		this.teacherseq = teacherseq;
	}

	public String getSubjectseq() {
		return subjectseq;
	}

	public void setSubjectseq(String subjectseq) {
		this.subjectseq = subjectseq;
	}

}
