package com.project2.main;

public class SilgiAnswerDTO {

	private String seq;
	private String answer;
	private String silgiexamseq;
	private String learningseq;
	private String courseSubjectSeq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getSilgiexamseq() {
		return silgiexamseq;
	}

	public void setSilgiexamseq(String silgiexamseq) {
		this.silgiexamseq = silgiexamseq;
	}

	public String getLearningseq() {
		return learningseq;
	}

	public void setLearningseq(String learningseq) {
		this.learningseq = learningseq;
	}

	public String getCourseSubjectSeq() {
		return courseSubjectSeq;
	}

	public void setCourseSubjectSeq(String courseSubjectSeq) {
		this.courseSubjectSeq = courseSubjectSeq;
	}

}
