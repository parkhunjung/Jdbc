package com.project2.main;

public class StudyStudentDTO {

	private String seq;
	private String studyseq;
	private String learningseq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getStudyseq() {
		return studyseq;
	}

	public void setStudyseq(String studyseq) {
		this.studyseq = studyseq;
	}

	public String getLearningseq() {
		return learningseq;
	}

	public void setLearningseq(String learningseq) {
		this.learningseq = learningseq;
	}

}