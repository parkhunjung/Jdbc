package com.project2.teacher;

public interface ITeacherService {

	void grade();

	void attended();

	void lessonSchedule();

}
