package com.project2.student;

public interface StudentIService {
	void info();

	void lesson();

	void attended();

}
